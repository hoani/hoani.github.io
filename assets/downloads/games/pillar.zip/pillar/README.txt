Pillar
    by Hoani Bryson

Can you believe it... Skeletrex is back, and he's on the moon! 

There are only enough resources to build a single pillar to the moon and defeat Skeletrex, it's all or nothing!

For Linux/Mac users, you can play the game in browser here: 
https://gx.games/games/dem1ks/pillar/


Controls
    This is a one-button game. You can use the mouse, a keyboard or gamepad.
    Any button works (I think).

Credits
    All resources I have licenses for.

    Sound Effects - Levi Bilas Boas, Gamemaster Audio
    Fonts - Chequered Ink

    Color palettes used:
    - titanstone by polyphrog https://lospec.com/palette-list/titanstone
    - chocolate ichor by Qirlfriend https://lospec.com/palette-list/chocolate-ichor
    - chamomil3 by The War on Christmas https://lospec.com/palette-list/chamomil3
    - bluetiger-3c by Rytzi https://lospec.com/palette-list/bluetiger-3c
    - rusty-steam by Sumedh Natu https://lospec.com/palette-list/rusty-steam
    - shadow violet by polyphrog https://lospec.com/palette-list/shadow-violet

Development notes:

    Unfortunately, I had very little time to work on this - so I tried to make something minimal but fun.

    In terms of theme, as you build your pillar, there is no means to drop down safely - it's "all or nothing"

    The game is based on a prize winning arcade machine my wife won her first phone from.

